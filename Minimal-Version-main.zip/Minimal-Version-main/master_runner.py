import glob
import os
import datetime
import shutil
from copy import deepcopy
from multiprocessing import Process
from multiprocessing import Queue




SRC='./logger/Run.log'
TAR='Run.log'

def remove_files(files,*args):
  global python_files
  for i in args:
    python_files.remove(i)


def job_run_test(jobs,queue):
   process_id=os.getpid()
   task_list=deepcopy(jobs)
   queue.put((process_id,"PENDING",task_list))
   for job in jobs:
       os.system('py'+' '+job)
       queue.put(job)
       task_list.remove(job)
   queue.put((process_id,"COMPLETED",task_list))

def job_compile_result():
  os.system('py report.py')
    

def start_job():
  try:
     shutil.copyfile(SRC,TAR)
     os.remove(SRC) 
  except Exception as e:
     print("Missing run log")


if __name__=="__main__":
   try:
       task_register=dict()
       start_job()
       queue=Queue()
       python_files=glob.glob('*.py')
       remove_files(python_files,'runner.py','utility.py','report.py','allocate.py','startup.py','master_runner.py')
       job1=python_files[0:7]
       job2=python_files[7:15]
       job3=python_files[15:23]
       job4=python_files[23:31]
       job5=python_files[31:38]
       job6=python_files[38:]
       process1=Process(target=job_run_test,args=(job1,queue,))
       process2=Process(target=job_run_test,args=(job2,queue,))
       process3=Process(target=job_run_test,args=(job3,queue,))
       process4=Process(target=job_run_test,args=(job4,queue,))
       process5=Process(target=job_run_test,args=(job5,queue,))
       process6=Process(target=job_run_test,args=(job6,queue,))
       process1.start()
       process2.start()
       process3.start()
       process4.start()
       process5.start()
       process6.start()
       process1.join()
       process2.join()
       process3.join()
       process4.join()
       process5.join()
       process6.join()
       job_compile_result()
   except Exception as e:
      print("Exception occured")
   finally:
      while not queue.empty():
         obj=queue.get()
         task_register[obj[0]]=(obj[1],obj[2])
      with open("pending.txt",'w') as file:
          for val in task_register.values():
              if val[0]=="PENDING":
                 for module in val[1]:
                     file.write(module+"\n")
         
         

               
   
   
